<div align="center">
  <img src="./public/satmakon-shield.png" alt="SAT Makon" width="96" />

  <h1>SAT Makon</h1>

  <p><strong>Digital SAT preparation platform with an AI-powered Telegram consultant, lead intake API, and lightweight CRM integrations.</strong></p>

  <p>
    <a href="https://sat-makon.uz"><strong>Website</strong></a>
    ·
    <a href="#quick-start"><strong>Quick Start</strong></a>
    ·
    <a href="#architecture"><strong>Architecture</strong></a>
    ·
    <a href="#deployment"><strong>Deployment</strong></a>
  </p>

  <p>
    <img src="https://img.shields.io/badge/Python-3.12-3776AB?logo=python&logoColor=white" alt="Python 3.12" />
    <img src="https://img.shields.io/badge/FastAPI-0.115+-009688?logo=fastapi&logoColor=white" alt="FastAPI" />
    <img src="https://img.shields.io/badge/Telegram-Bot-26A5E4?logo=telegram&logoColor=white" alt="Telegram Bot" />
    <img src="https://img.shields.io/badge/Docker-Ready-2496ED?logo=docker&logoColor=white" alt="Docker" />
    <img src="https://img.shields.io/badge/Nginx-Production-009639?logo=nginx&logoColor=white" alt="Nginx" />
  </p>
</div>

---

![SAT Makon preview](./public/og-image.png)

## About

**SAT Makon** is a production-oriented platform for SAT education and student acquisition. The project combines a public website, a Telegram-based AI consultant, a FastAPI lead endpoint, optional Google Sheets CRM logging, and Docker/Nginx deployment infrastructure in one repository.

The Telegram assistant can communicate with prospective students and parents, preserve conversation context, collect contact information, identify visit intent, extract visit date/time/topic, and notify the administration team. Website consultation requests are delivered to the same Telegram admin workflow through the FastAPI backend.

## Key Features

- **Responsive public website** served from `public/`.
- **Telegram AI consultant** built with `python-telegram-bot`.
- **DeepSeek integration** through an OpenAI-compatible API.
- **Fallback lead collection** even when the AI provider is unavailable.
- **Website lead API** powered by FastAPI and Uvicorn.
- **Telegram admin notifications** for new website and bot leads.
- **Visit intent extraction** from natural-language conversations.
- **Persistent conversation state** stored under `data/`.
- **Google Sheets integration** for conversations, admin summaries, and visit planning.
- **Anti-spam protection** with IP-based rate limiting and a honeypot field.
- **CORS configuration** for local and production frontend origins.
- **Dockerized production setup** with separate site and bot/API containers.
- **Nginx reverse proxy** for static content, `/api/`, compression, caching, and health checks.

## Architecture

```mermaid
flowchart LR
    V[Website Visitor] --> EDGE[Edge Nginx / HTTPS]
    EDGE --> SITE[sat-makon-site\nNginx]
    SITE --> STATIC[Static Website]
    SITE -->|/api/*| API[FastAPI Lead API]

    T[Telegram User] --> BOT[Telegram Bot]
    API --> ADMIN[Telegram Admin Group]
    BOT --> ADMIN

    BOT --> AI[DeepSeek API]
    BOT --> SHEETS[Google Sheets]
    BOT --> DATA[(data/*.json)]

    subgraph BOTCONTAINER[sat-makon-bot container]
        BOT
        API
    end
```

In production, the website and backend are intentionally separated into two containers:

- `sat-makon-site` — Nginx serving the static frontend and proxying `/api/`.
- `sat-makon-bot` — Telegram polling process plus the FastAPI lead service on port `8000`.

## Tech Stack

| Area | Technology |
|---|---|
| Backend | Python 3.12, FastAPI, Uvicorn |
| Telegram | python-telegram-bot |
| AI | DeepSeek via OpenAI-compatible client |
| CRM / Logging | Google Sheets, gspread |
| Frontend | Static HTML/CSS/JavaScript |
| Web server | Nginx |
| Deployment | Docker, Docker Compose |
| Configuration | python-dotenv |
| HTTP client | httpx |

## Project Structure

```text
.
├── bot.py                  # Telegram bot, AI workflow, visit detection
├── lead_api.py             # FastAPI website lead endpoint
├── prompts.py              # AI system prompts and assistant behavior
├── sheets.py               # Google Sheets logging / CRM integration
├── test_group.py           # Telegram admin-group connection test
│
├── public/                 # Production frontend and static assets
│   ├── index.html
│   ├── students/
│   ├── teachers/
│   └── unis/
│
├── data/                   # Runtime bot state (ignored by Git)
│   └── .gitkeep
│
├── Dockerfile.bot          # Telegram bot + FastAPI image
├── Dockerfile.site         # Nginx static site image
├── docker-compose.yml      # Production container orchestration
├── site.conf               # Nginx site/API proxy configuration
├── requirements.txt
├── runtime.txt
├── Procfile
├── .env.example
└── .gitignore
```

## Quick Start

### Prerequisites

Make sure you have:

- Git
- Python **3.12+**
- A Telegram bot token from `@BotFather`
- A Telegram admin group/chat ID

DeepSeek and Google Sheets are optional. The bot can still collect leads without them.

### 1. Clone the repository

```bash
git clone https://github.com/d3bka/SatMakon.uz.git
cd SatMakon.uz
```

### 2. Create a virtual environment

#### Windows PowerShell

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

#### Linux / macOS

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 3. Create the environment file

#### Windows PowerShell

```powershell
Copy-Item .env.example .env
```

#### Linux / macOS

```bash
cp .env.example .env
```

Then configure the required values in `.env`.

## Environment Variables

| Variable | Required | Purpose |
|---|---:|---|
| `TELEGRAM_BOT_TOKEN` | Yes | Telegram bot token from `@BotFather` |
| `ADMIN_GROUP_CHAT_ID` | Yes | Destination Telegram group/chat for leads and notifications |
| `DEEPSEEK_API_KEY` | No | Enables AI-powered replies and structured extraction |
| `GOOGLE_CREDENTIALS` | No | Google service-account JSON for Sheets integration |
| `GOOGLE_SHEET_ID` | No | Google Spreadsheet ID |
| `ENABLE_LEAD_API` | No | Enables/disables the website lead API; default is enabled |
| `LEAD_API_HOST` | No | API bind host; use `127.0.0.1` locally and `0.0.0.0` in Docker |
| `LEAD_API_PORT` | No | API port; default `8000` |
| `LEAD_ALLOWED_ORIGINS` | No | Comma-separated CORS origins |
| `FORWARDED_ALLOW_IPS` | Production | Trusted proxy addresses for correct forwarded client IP handling |

Example:

```env
TELEGRAM_BOT_TOKEN=your_bot_token
ADMIN_GROUP_CHAT_ID=your_admin_chat_id

DEEPSEEK_API_KEY=
GOOGLE_CREDENTIALS=
GOOGLE_SHEET_ID=

ENABLE_LEAD_API=1
LEAD_API_HOST=127.0.0.1
LEAD_API_PORT=8000
LEAD_ALLOWED_ORIGINS=http://127.0.0.1:8000,http://localhost:8000
```

> Never commit `.env`, service-account credentials, API keys, or Telegram tokens to Git.

## Run Locally

Start the Telegram bot and the website API with one command:

```bash
python bot.py
```

By default:

- Website: `http://127.0.0.1:8000/`
- Health check: `http://127.0.0.1:8000/health`
- Lead endpoint: `POST http://127.0.0.1:8000/api/leads`
- Telegram bot: polling mode

The FastAPI server is started by `bot.py` in a background thread, so the bot and lead API run together locally.

## Test Telegram Configuration

Before starting the full application, verify that the bot can send a message to the configured admin group:

```bash
python test_group.py
```

A successful setup prints:

```text
Test message sent successfully.
```

## Lead API

### Health check

```http
GET /health
```

Example response:

```json
{
  "ok": true,
  "telegram_configured": true
}
```

### Submit a website lead

```http
POST /api/leads
Content-Type: application/json
```

```json
{
  "name": "Student Name",
  "phone": "+998901234567",
  "source": "website",
  "website": ""
}
```

The `website` field is a honeypot used to silently ignore simple automated spam submissions.

The API also limits successful submissions from a non-local IP to **5 requests per 10 minutes**.

## Google Sheets Integration

When `GOOGLE_CREDENTIALS` and `GOOGLE_SHEET_ID` are configured, the application automatically maintains three worksheets:

- `Suhbatlar` — raw conversation history.
- `Admin` — latest user status and summarized lead information.
- `Taqvim` — planned visits with date, time, phone, and topic.

If Google Sheets is not configured, the core Telegram and website lead flow continues to work.

## Telegram Commands

| Command | Description |
|---|---|
| `/start` | Starts the assistant conversation |
| `/reset` | Clears stored conversation context for the current user |
| `/stats` | Displays current bot session statistics |
| `/chatid` | Shows the current Telegram chat ID |

## Deployment

### Docker images

Build the site container:

```bash
docker build -f Dockerfile.site -t sat-makon-site .
```

Build the bot/API container:

```bash
docker build -f Dockerfile.bot -t sat-makon-bot .
```

The included `docker-compose.yml` is designed for the current VPS architecture and pulls pre-built images by default.

### Production flow

```text
Internet
   │
   ▼
Edge Nginx :80/:443
   │
   ▼
sat-makon-site :80
   ├── /             → static frontend
   └── /api/*        → sat-makon-bot:8000
                              │
                              ├── Telegram
                              ├── DeepSeek
                              └── Google Sheets
```

For Docker production configuration, use at least:

```env
LEAD_API_HOST=0.0.0.0
LEAD_API_PORT=8000
FORWARDED_ALLOW_IPS=*
LEAD_ALLOWED_ORIGINS=https://sat-makon.uz,https://www.sat-makon.uz
```

The compose file expects an external Docker network named `sat_makon_network`.

If it does not already exist:

```bash
docker network create sat_makon_network
```

Then start the services:

```bash
docker compose pull
docker compose up -d
```

Check status:

```bash
docker compose ps
```

View logs:

```bash
docker compose logs -f
```

## Security Notes

- `.env` is ignored by Git and must remain private.
- Runtime JSON files under `data/` are ignored to avoid publishing conversation state and phone data.
- Telegram request URLs are intentionally not logged because they contain the bot token.
- Website submissions include a honeypot and rate limiter.
- In production, port `8000` should stay internal and be accessed through Nginx rather than published directly to the internet.
- Rotate any credential immediately if it has ever been exposed in a public repository, screenshot, log, or chat.

## Operational Health Checks

Site container:

```text
GET /healthz
```

Bot/API container:

```text
GET /health
```

Both containers include Docker health checks in `docker-compose.yml`.

## Development Workflow

Typical Git workflow after making changes:

```bash
git status
git add .
git commit -m "Describe your changes"
git push
```

Before committing, verify that no secrets are staged:

```bash
git status
```

## Additional Documentation

For the existing Russian local-run notes, see [`README_RUN_RU.md`](./README_RUN_RU.md).

---

<div align="center">
  <strong>SAT Makon</strong><br />
  Helping students move from preparation to opportunity.
</div>
